

#include "config.h"
#include "hardware_handler.h"
#include "hardware/i2c.h"
#include "ssd1306_font.h" 

// Definições e Comandos do SSD1306
#define SSD1306_I2C_ADDR 0x3C
#define SSD1306_HEIGHT 64
#define SSD1306_WIDTH 128
#define SSD1306_NUM_PAGES (SSD1306_HEIGHT / 8)
#define SSD1306_BUF_LEN (SSD1306_NUM_PAGES * SSD1306_WIDTH)

#define SSD1306_SET_DISPLAY_ON 0xAF
#define SSD1306_SET_DISPLAY_OFF 0xAE
#define SSD1306_SET_CONTRAST 0x81
#define SSD1306_SET_ENTIRE_ON 0xA4
#define SSD1306_SET_NORMAL_DISPLAY 0xA6
#define SSD1306_SET_MEMORY_MODE 0x20
#define SSD1306_SET_PAGE_ADDRESS 0x22
#define SSD1306_SET_COLUMN_ADDRESS 0x21

static uint8_t oled_buffer[SSD1306_BUF_LEN];

static void oled_send_cmd(uint8_t cmd) {
    uint8_t buf[2] = {0x80, cmd};
    i2c_write_blocking(i2c1, SSD1306_I2C_ADDR, buf, 2, false);
}

static void oled_render() {
    oled_send_cmd(SSD1306_SET_COLUMN_ADDRESS);
    oled_send_cmd(0); oled_send_cmd(SSD1306_WIDTH - 1);
    oled_send_cmd(SSD1306_SET_PAGE_ADDRESS);
    oled_send_cmd(0); oled_send_cmd(SSD1306_NUM_PAGES - 1);
    uint8_t buf[SSD1306_BUF_LEN + 1];
    buf[0] = 0x40;
    memcpy(buf + 1, oled_buffer, SSD1306_BUF_LEN);
    i2c_write_blocking(i2c1, SSD1306_I2C_ADDR, buf, sizeof(buf), false);
}

static void oled_draw_char(int16_t x, int16_t y, char c) {
    if (x < 0 || x >= SSD1306_WIDTH || y < 0 || y >= SSD1306_HEIGHT) return;
    int char_idx = (c >= 'A' && c <= 'Z') ? (c - 'A' + 1) : ((c >= 'a' && c <= 'z') ? (c - 'a' + 1) : ((c >= '0' && c <= '9') ? (c - '0' + 27) : 0));
    for (int i = 0; i < 8; i++) {
        uint8_t line = font[char_idx * 8 + i];
        for (int j = 0; j < 8; j++) {
            if ((line >> j) & 1) {
                int px = x + i; int py = y + j;
                if (px < SSD1306_WIDTH && py < SSD1306_HEIGHT) {
                    int byte_idx = (py / 8) * SSD1306_WIDTH + px;
                    if(byte_idx < sizeof(oled_buffer)) oled_buffer[byte_idx] |= (1 << (py % 8));
                }
            }
        }
    }
}

static void oled_draw_string(int16_t x, int16_t y, const char *s) {
    while (*s) { oled_draw_char(x, y, *s++); x += 8; }
}

// Lógica do Sensor AHT10
#define AHT10_ADDR 0x38
#define AHT10_CMD_CALIBRATE 0xE1
#define AHT10_CMD_TRIGGER   0xAC

void hardware_init() {
    i2c_init(i2c0, 100 * 1000); // I2C0 para Sensor
    gpio_set_function(I2C0_SDA_PIN, GPIO_FUNC_I2C); gpio_pull_up(I2C0_SDA_PIN);
    gpio_set_function(I2C0_SCL_PIN, GPIO_FUNC_I2C); gpio_pull_up(I2C0_SCL_PIN);

    i2c_init(i2c1, 400 * 1000); // I2C1 para Display
    gpio_set_function(I2C1_SDA_PIN, GPIO_FUNC_I2C); gpio_pull_up(I2C1_SDA_PIN);
    gpio_set_function(I2C1_SCL_PIN, GPIO_FUNC_I2C); gpio_pull_up(I2C1_SCL_PIN);

    gpio_init(LED_ALERTA_PIN); gpio_set_dir(LED_ALERTA_PIN, GPIO_OUT);
    gpio_init(BOTAO_PRESENCA_PIN); gpio_set_dir(BOTAO_PRESENCA_PIN, GPIO_IN); gpio_pull_up(BOTAO_PRESENCA_PIN);
    gpio_init(BOTAO_URGENCIA_PIN); gpio_set_dir(BOTAO_URGENCIA_PIN, GPIO_IN); gpio_pull_up(BOTAO_URGENCIA_PIN);

    oled_send_cmd(SSD1306_SET_DISPLAY_OFF);
    oled_send_cmd(0xD5); oled_send_cmd(0x80); oled_send_cmd(0xA8); oled_send_cmd(SSD1306_HEIGHT - 1);
    oled_send_cmd(0xD3); oled_send_cmd(0x0); oled_send_cmd(0x40); oled_send_cmd(0x8D); oled_send_cmd(0x14);
    oled_send_cmd(0x20); oled_send_cmd(0x00); oled_send_cmd(0xA1); oled_send_cmd(0xC8);
    oled_send_cmd(0xDA); oled_send_cmd(0x12); oled_send_cmd(SSD1306_SET_CONTRAST); oled_send_cmd(0xFF);
    oled_send_cmd(0xD9); oled_send_cmd(0xF1); oled_send_cmd(0xDB); oled_send_cmd(0x40);
    oled_send_cmd(SSD1306_SET_ENTIRE_ON); oled_send_cmd(SSD1306_SET_NORMAL_DISPLAY);
    oled_send_cmd(SSD1306_SET_DISPLAY_ON);
    
    uint8_t cmd_calib[] = {AHT10_CMD_CALIBRATE, 0x08, 0x00};
    i2c_write_blocking(i2c0, AHT10_ADDR, cmd_calib, sizeof(cmd_calib), false);
    sleep_ms(20);
    
    hardware_oled_exibir("Hardware OK!", "");
}

void hardware_oled_exibir(const char* linha1, const char* linha2) {
    memset(oled_buffer, 0, sizeof(oled_buffer));
    oled_draw_string(0, 8, linha1);
    oled_draw_string(0, 24, linha2);
    oled_render();
}

void hardware_oled_limpar() {
    memset(oled_buffer, 0, sizeof(oled_buffer));
    oled_render();
}

bool hardware_ler_sensor(float *temperatura, float *umidade) {
    uint8_t trigger_cmd[] = {AHT10_CMD_TRIGGER, 0x33, 0x00};
    i2c_write_blocking(i2c0, AHT10_ADDR, trigger_cmd, sizeof(trigger_cmd), false);
    sleep_ms(80);
    uint8_t data[6];
    int result = i2c_read_blocking(i2c0, AHT10_ADDR, data, sizeof(data), false);
    if (result != sizeof(data) || (data[0] & 0x80)) return false;
    uint32_t raw_hum = (((uint32_t)data[1] << 12) | ((uint32_t)data[2] << 4) | (data[3] >> 4));
    uint32_t raw_temp = ((uint32_t)(data[3] & 0x0F) << 16) | ((uint32_t)data[4] << 8) | data[5];
    *umidade = (raw_hum * 100.0f) / 1048576.0f;
    *temperatura = ((raw_temp * 200.0f) / 1048576.0f) - 50.0f;
    return true;
}

void hardware_led_set(bool on) { gpio_put(LED_ALERTA_PIN, on); }
bool hardware_botao_presenca_pressionado() { return !gpio_get(BOTAO_PRESENCA_PIN); }
bool hardware_botao_urgencia_pressionado() { return !gpio_get(BOTAO_URGENCIA_PIN); }