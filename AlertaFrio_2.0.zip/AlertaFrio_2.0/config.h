// config.h - VERSÃO COMPLETA E CORRETA

#ifndef CONFIG_H
#define CONFIG_H

#include <stdio.h>
#include <string.h>
#include "pico/stdlib.h"
#include "hardware/i2c.h"
#include "hardware/timer.h"
#include "pico/cyw43_arch.h"

// --- CONFIGURAÇÃO DO HARDWARE ---
#define LED_ALERTA_PIN 13
#define BOTAO_PRESENCA_PIN 5
#define BOTAO_URGENCIA_PIN 6

// --- CONFIGURAÇÃO DA LÓGICA ---
#define TEMPERATURA_LIMIAR 20.0f // Você pode ajustar este valor

// --- CONFIGURAÇÃO DAS PORTAS I2C ---
// Porta I2C 0 (Sensor de Temperatura Externo)
#define I2C0_PORT i2c0
#define I2C0_SDA_PIN 0
#define I2C0_SCL_PIN 1

// Porta I2C 1 (Display OLED na Placa)
#define I2C1_PORT i2c1
#define I2C1_SDA_PIN 14 // Pino padrão para I2C1 SDA
#define I2C1_SCL_PIN 15 // Pino padrão para I2C1 SCL


// --- CONFIGURAÇÃO DE REDE E MQTT ---
#define WIFI_SSID "TP-Link_IoT_D3DB"
#define WIFI_PASSWORD "12345678"
#define MQTT_BROKER_IP "192.168.1.5"
#define MQTT_BROKER_PORT 1883 // Porta padrão do MQTT
#define MQTT_CLIENT_ID "PicoW_AlertaFrio_Kesia"


// --- TÓPICOS MQTT ---
#define TOPICO_STATUS "supermercado/caixa01/status"
#define TOPICO_ALERTA "supermercado/caixa01/alerta"
#define TOPICO_COMANDO "supermercado/caixa01/comando"
#define TOPICO_URGENTE "supermercado/caixa01/urgente"


#endif // CONFIG_H