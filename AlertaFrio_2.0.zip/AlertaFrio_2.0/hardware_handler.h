// hardware_handler.h

#ifndef HARDWARE_HANDLER_H
#define HARDWARE_HANDLER_H

#include <stdbool.h> // Necessário para usar os tipos 'true' e 'false'

/**
 * @brief Inicializa todo o hardware necessário (as duas portas I2C, GPIOs, Sensores, Display).
 * Deve ser chamada uma vez no início do programa.
 */
void hardware_init();

/**
 * @brief Lê os dados do sensor AHT10 na porta I2C0.
 *
 * @param temperatura Ponteiro para uma variável float onde a temperatura será armazenada.
 * @param umidade Ponteiro para uma variável float onde a umidade será armazenada.
 * @return true se a leitura for bem-sucedida, false caso contrário.
 */
bool hardware_ler_sensor(float *temperatura, float *umidade);

/**
 * @brief Define o estado do LED de alerta.
 *
 * @param on true para ligar o LED, false para desligar.
 */
void hardware_led_set(bool on);

/**
 * @brief Exibe duas linhas de texto no display OLED na porta I2C1.
 *
 * @param linha1 Ponteiro para a string da primeira linha.
 * @param linha2 Ponteiro para a string da segunda linha.
 */
void hardware_oled_exibir(const char* linha1, const char* linha2);

/**
 * @brief Limpa completamente a tela do display OLED.
 */
void hardware_oled_limpar();

/**
 * @brief Verifica se o botão de presença está pressionado.
 *
 * @return true se o botão estiver pressionado, false caso contrário.
 */
bool hardware_botao_presenca_pressionado();

/**
 * @brief Verifica se o botão de urgência está pressionado.
 *
 * @return true se o botão estiver pressionado, false caso contrário.
 */
bool hardware_botao_urgencia_pressionado();

#endif // HARDWARE_OLED_H